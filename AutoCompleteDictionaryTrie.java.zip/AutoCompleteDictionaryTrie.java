package spelling;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;

import com.sun.xml.internal.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;

/** 
 * An trie data structure that implements the Dictionary and the AutoComplete ADT
 * @author You
 *
 */
public class AutoCompleteDictionaryTrie implements Dictionary, AutoComplete {

    private TrieNode root;
    private int size;

    public AutoCompleteDictionaryTrie()
	{
		root = new TrieNode();
		
	}
	
	
	/** Insert a word into the trie.
	 * For the basic part of the assignment (part 2), you should ignore the word's case.
	 * That is, you should convert the string to all lower case as you insert it. */
	public boolean addWord(String word) {
		// Implement this method.
		word = word.toLowerCase();

		TrieNode currentNode = root;
		for (Character c : word.toCharArray()) {
			TrieNode child = currentNode.getChild(c);
			if (child == null)
				currentNode = currentNode.insert(c);
			else
				currentNode = child;
		}
		
		if (currentNode.endsWord())
			return false;

		currentNode.setEndsWord(true);
		size++;
		return true;
	}
	
	/** 
	 * Return the number of words in the dictionary.  This is NOT necessarily the same
	 * as the number of TrieNodes in the trie.
	 */
	public int size()
	{	
	    return size;
	}
	
	
	/** Returns whether the string is a word in the trie */
	@Override
	public boolean isWord(String s) 
	{
	    // TODO: Implement this method
		TrieNode current = root;
		String text = s.toLowerCase();
		if (text == "") {
			return false;
		}
		for (int i = 0; i<text.length(); i++) {
			char c = text.charAt(i);
			TrieNode test = current.getChild(c);
			if(test == null) {
				return false;
			} else {
				current = test;
			}
		}
		if(current.endsWord()) {
			return true;
		} else {
			return false;
		}
	}

	/** 
	 *  * Returns up to the n "best" predictions, including the word itself,
     * in terms of length
     * If this string is not in the trie, it returns null.
     * @param text The text to use at the word stem
     * @param n The maximum number of predictions desired.
     * @return A list containing the up to n best predictions
     */@Override
     public List<String> predictCompletions(String prefix, int numCompletions) 
     {
    	 // TODO: Implement this method
    	 // This method should implement the following algorithm:
    	 // 1. Find the stem in the trie.  If the stem does not appear in the trie, return an
    	 //    empty list
    	 //LinkedList<String> queue;
    	 prefix = prefix.toLowerCase();
    	 
    	 TrieNode current = root;
    	 
    	 for (int i = 0; i < prefix.length(); i++) {
    		 char c = prefix.charAt(i);
    		 TrieNode test = current.getChild(c);
    		 if (test != null) {
    			 current = test;
    		 }
    		 else {
    			 return new LinkedList<String>(); 
    		 }
    	 }
    	 // 2. Once the stem is found, perform a breadth first search to generate completions
    	 //    using the following algorithxm:
    	 
    	 //    Create a queue (LinkedList) and add the node that completes the stem to the back
    	 //       of the list.
    	 LinkedList<TrieNode> q = new LinkedList<TrieNode>();
    	 q.addLast(current);
    	 
    	 // Create a list of completions to return (initially empty)
    	 LinkedList<String> completions = new LinkedList<String>();

    	 // While the queue is not empty and you don't have enough completions:
    	 while(!q.isEmpty() && completions.size() < numCompletions) {
    		// remove the first Node from the queue
    		TrieNode r = q.removeFirst();
   		    
    		// If it is a word, add it to the completions list
    		String rText = r.getText();
    		if (isWord(rText)) {
    			completions.addLast(rText);
    		}
    		// Add all of its child nodes to the back of the queue
    		for(TrieNode child : r.children.values()) {
    			q.addLast(child);
    		}
    		
    	}
    	 // Return the list of completions
    	 return completions;
     }

 	// For debugging
 	public void printTree()
 	{
 		printNode(root);
 	}
 	
 	/** Do a pre-order traversal from this node down */
 	public void printNode(TrieNode curr)
 	{
 		if (curr == null) 
 			return;
 		
 		System.out.println(curr.getText());
 		
 		TrieNode next = null;
 		for (Character c : curr.getValidNextCharacters()) {
 			next = curr.getChild(c);
 			printNode(next);
 		}
 	}
 	

	
}